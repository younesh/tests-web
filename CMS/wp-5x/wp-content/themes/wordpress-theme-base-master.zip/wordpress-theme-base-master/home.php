<?php
/**
 * The home page. Uses archive.
 * See http://wphierarchy.com for help.
 */
namespace Vincit;

require "archive.php";
