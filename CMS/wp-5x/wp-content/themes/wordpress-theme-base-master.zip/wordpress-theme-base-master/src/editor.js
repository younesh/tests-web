/**
 * This file can be used to customize the TinyMCE editor.
 * dist/editor.js & dist/editor.css are built using this file.
 * Note that WP doesn't provide a way to add your own JavaScript
 * to the editor iframe. You're going to have to inject into the iframe
 * if you require JavaScript customizations for the editor.
 */
import './editor.styl';
