<?php get_header(); ?>

<div class="container">
  <article>
    <h1>404 - Nothing found</h1>

    <p>
      <button class="tremor">Entertain me</button>
    </p>
  </article>
</div>

<?php get_footer(); ?>
