<?php
/**
 * There isn't a good reason for this namespace to even exist.
 */
namespace Vincit\WP;
