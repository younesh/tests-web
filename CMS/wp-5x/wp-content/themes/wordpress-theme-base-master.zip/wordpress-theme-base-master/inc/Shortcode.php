<?php
/**
 * Register any shortcodes here, or apply any changes to shortcodes here.
 */
namespace Vincit\Shortcode;
