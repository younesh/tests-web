<?php
/**
 * Register custom post types and taxonomies here.
 */
namespace Vincit\CCT;

/* add_action('init', function () {
  register_post_type(
    'news',
    [
      'labels' => [
        'name' => __('News'),
        'singular_name' => __('News'),
        'archives' => __('News'),
      ],
      'public' => true, // has to be public in order to appear in nav menus
      'has_archive' => true,
      'rewrite' => [
        'slug' => 'news',
      ],
    ]
  );
}); */
