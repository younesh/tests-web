<?php
/*
 * pre_get_posts and others here
 */
namespace Vincit\QueryModifiers;
