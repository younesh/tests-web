<?php
/**
 * Single post page for anything that's not a page.
 */

namespace Vincit;

require "singular.php";
