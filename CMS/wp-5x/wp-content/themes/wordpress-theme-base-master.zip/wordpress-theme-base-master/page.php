<?php
/**
 * Singular page for pages.
 */

namespace Vincit;

require "singular.php";
